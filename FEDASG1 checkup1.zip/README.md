# FED-ASG1
This is my repository for my Front End Development module assignment 1. This assignment will be making a simple pre-registration website about a fictional game. This website will allow you to 
